<?php include('templates/header.php'); ?>
                    <nav class="site-navigation d-flex justify-content-end align-items-center">
                        <ul class="d-flex flex-column flex-lg-row justify-content-lg-end align-content-center">
                            <li><a href="index.php">Home</a></li>
                            <li class="current-menu-item"><a href="about.php">About us</a></li>
                            <li><a href="causes.php">Causes</a></li>
                            <li><a href="portfolio.php">Gallery</a></li>
                            <li><a href="projects.php">Projects</a></li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </nav><!-- .site-navigation -->
                    <div class="hamburger-menu d-lg-none">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                    </div><!-- .hamburger-menu -->
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .nav-bar -->
</header><!-- .site-header -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>About Us</h1>
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .page-header -->
    <div class="welcome-wrap">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-6 order-2 order-lg-1">
                    <div class="welcome-content">
                        <header class="entry-header">
                            <h2 class="entry-title">Why the organisation was started</h2>
                        </header><!-- .entry-header -->
                        <div class="entry-content mt-5">
                            <p>Owing to the very rapidly raising number of number vulnerable children
                              suffering on streets and some other poor homes of Uganda due loss of their parents,
                              family neglegency, our organization was started to help
                              these marginalized. This was done to help these humble children have
                              a better future too. The  started with  of 21 children and the organisation
                               is currently taking care of 43 children.</p>
                        </div>
                    </div><!-- .welcome-content -->
                </div><!-- .col -->
                <div class="col-12 col-lg-6 order-1 order-lg-2">
                    <img src="images/about.jpg" alt="about">
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->
    <div class="welcome-wrap" style="margin-top:40px;">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-4 order-2 order-lg-1">
                    <div class="welcome-content">
                        <header class="entry-header">
                            <h2 class="entry-title" style="color:#000;">
                              Who we are</h2>
                        </header><!-- .entry-header -->
                        <div class="entry-content mt-5">
                            <p>
                              We are a registered Non Government Organisation,
                              community based organisation focusing on helping the
                              most vulnurable and maginarised children to have better
                              living standards in the society.
                             </p>
                        </div>
                    </div><!-- .welcome-content -->
                </div><!-- .col -->
                <div class="col-12 col-lg-4 order-2 order-lg-1">
                    <div class="welcome-content">
                        <header class="entry-header">
                            <h2 class="entry-title" style="color:#000;">
                              What we do</h2>
                        </header><!-- .entry-header -->
                        <div class="entry-content mt-5">
                            <p>
                              Owing to the fact that most vulnerable children too have a right
                              to the better future, we help them have access to it too.
                             </p>
                        </div>
                    </div><!-- .welcome-content -->
                </div><!-- .col -->
                <div class="col-12 col-lg-4 order-2 order-lg-1">
                    <div class="welcome-content">
                        <header class="entry-header">
                            <h2 class="entry-title" style="color:#000;">
                              Where we work</h2>
                        </header><!-- .entry-header -->
                        <div class="entry-content mt-5">
                            <p>
                              In the different communities of Mityana
                               and especially the families with the most vulnerable children.
                            </p>
                        </div>
                    </div><!-- .welcome-content -->
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->
    <?php include('testimonies.php'); ?>
    <div class="help-us">
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-wrap justify-content-between align-items-center">
                    <h2>Help us so we can help others</h2>
                    <a class="btn orange-border" href="donate.php">Donate now</a>
                </div>
            </div>
        </div>
    </div>
<?php include('templates/footer.php'); ?>
