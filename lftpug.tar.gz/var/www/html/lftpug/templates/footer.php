<footer class="site-footer">
    <div class="footer-widgets">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 col-lg-3">
                    <div class="foot-about">
                        <h2>
                          <a class="foot-logo" href="#"><img src="images/header.jpg" alt=""></a>
                        </h2>
                        <p>
                          Love For The Poor Organisation Uganda (LFTP -UG) is a registered Non
                          Profit organization in Uganda. We were founded to help the most vulnerable
                          children in the different areas of Uganda.
                           <a href="#" style="float:right;">Read More</a>
                        </p>
                        <ul class="d-flex flex-wrap align-items-center">
                            <li><a href="https://www.facebook.com"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://www.twitter.com"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="https://www.instagram.com"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://www.linkedin.com"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div><!-- .foot-about -->
                </div><!-- .col -->

                <div class="col-12 col-md-6 col-lg-3 mt-5 mt-md-0">
                    <h2>Useful Links</h2
                    <ul>
                        <li><a href="index.php" style="color:#fff;">Home</a></li>
                        <li><a href="about.php" style="color:#fff;">About</a></li>
                        <li><a href="causes.php" style="color:#fff;">Causes</a></li>
                        <li><a href="gallery.php" style="color:#fff;">Gallery</a></li>
                        <li><a href="projects.php" style="color:#fff;">Projects</a></li>
                        <li><a href="contact.php" style="color:#fff;">Contacts</a></li>
                    </ul>
                </div><!-- .col -->
                <div class="col-12 col-md-6 col-lg-3 mt-5 mt-md-0">
                  <h2>Vision</h2>
                    <div class="foot-latest-news">
                        <p>
                          Justice and free society for vulnerable children.
                        </p>
                    </div><!-- .foot-latest-news -->
                    <h2>Mission</h2>
                      <div class="foot-latest-news">
                          <p>
                            To provide productive healthy and God fearing citizens
                            equipped with appropriate skills and principles to achieve success in life.
                          </p>
                      </div><!-- .foot-latest-news -->
                </div><!-- .col -->
                <div class="col-12 col-md-6 col-lg-3 mt-5 mt-md-0">
                    <div class="foot-contact">
                        <h2>Contact</h2>
                        <ul>
                            <li><i class="fa fa-phone"></i>
                              <span>+256 775 779 112 <br> +256 753 492 567 </span>
                            </li>
                            <li><i class="fa fa-envelope"></i>
                              <span>info@lftpug.org <br> loveforthepoor8@gmail.com</span>
                            </li>
                            <li><i class="fa fa-map-marker"></i><span>Mityana, Uganda - East Africa.</span></li>
                        </ul>
                    </div><!-- .foot-contact -->
                    <div class="subscribe-form">
                        <form class="d-flex flex-wrap align-items-center">
                            <input type="email" placeholder="Your email">
                            <input type="submit" value="send">
                        </form><!-- .flex -->
                    </div><!-- .search-widget -->
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .footer-widgets -->
    <div class="footer-bar" style="background-color:#222;">
        <div class="container">
            <div class="row">
            	<div class="col-6">
                    <p class="m-0" style="color:#fff;">Love For The Poor</p>
                </div>
                <div class="col-6">
                    <p class="m-0" style="color:#fff;">Powered by Novus Terra.</p>
                </div>
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .footer-bar -->
</footer><!-- .site-footer -->
<script type='text/javascript' src='js/jquery.js'></script>
<script type='text/javascript' src='js/jquery.collapsible.min.js'></script>
<script type='text/javascript' src='js/swiper.min.js'></script>
<script type='text/javascript' src='js/jquery.countdown.min.js'></script>
<script type='text/javascript' src='js/circle-progress.min.js'></script>
<script type='text/javascript' src='js/jquery.countTo.min.js'></script>
<script type='text/javascript' src='js/jquery.barfiller.js'></script>
<script type='text/javascript' src='js/custom.js'></script>


</body>
</html>
