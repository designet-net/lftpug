<div class="our-causes">
    <div class="container">
        <div class="row">
            <div class="coL-12">
                <div class="section-heading">
                    <h2 class="entry-title">Our Causes</h2>
                </div><!-- .section-heading -->
            </div><!-- .col -->
        </div><!-- .row -->
        <div>
        	<div class="coL-12 col-lg-12">
            	<h4 class="entry-title" style="color:red;margin:20px;">We are all called to serve each other. 1 Peter 4:10-11</h4>
            	<p>
                	Each of you should use whatever gift you have received to serve others, as faithful stewards of God's grace in its various forms. 
                    If anyone speaks, they should do so as one who speaks the very words of God.
                </p>
            </div>
        </div>
        <div class="row">
        	<div class="coL-12 col-lg-4">
             	<img src ="images/c_1.jpg" width="100%" height="auto"/>
            </div>
            <div class="coL-12 col-lg-4">
             	<img src ="images/c_2.jpg" width="100%" height="auto"/>
            </div>
            <div class="coL-12 col-lg-4">
             	<img src ="images/c_3.jpg" width="100%" height="auto"/>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="swiper-container causes-slider">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="cause-wrap">
                                <figure class="m-0">
                                    <img src="images/poor_feeding.jpg" alt="">
                                    <div class="figure-overlay d-flex justify-content-center align-items-center position-absolute w-100 h-100">
                                        <a href="index.php#donate" class="btn gradient-bg mr-2">Donate Now</a>
                                    </div><!-- .figure-overlay -->
                                </figure>
                                <div class="cause-content-wrap">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <h3 class="entry-title w-100 m-0">
                                          <a href="poor_feeding.php">Poor Feeding</a></h3>
                                    </header><!-- .entry-header -->
                                    <div class="entry-content">
                                        <p class="m-0">
                                          Because of limited food in our communities the vulnerable
                                          children end up feeding on jack fruits. These works as their
                                           meals(break fast, lunch and supper). This does not only
                                           affect the vulnerable children
                                        </p>
                                    </div>
                                </div><!-- .cause-content-wrap -->
                            </div><!-- .cause-wrap -->
                        </div><!-- .swiper-slide -->
                        <div class="swiper-slide">
                            <div class="cause-wrap">
                                <figure class="m-0">
                                    <img src="images/widows.jpg" alt="">
                                    <div class="figure-overlay d-flex justify-content-center align-items-center position-absolute w-100 h-100">
                                        <a href="index.php#donate" class="btn gradient-bg mr-2">Donate Now</a>
                                    </div><!-- .figure-overlay -->
                                </figure>
                                <div class="cause-content-wrap">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <h3 class="entry-title w-100 m-0">
                                          <a href="widows.php">Widows/ Elderly</a></h3>
                                    </header><!-- .entry-header -->
                                    <div class="entry-content">
                                        <p class="m-0">
                                          Many of the widows in Uganda lose their husbands at an early
                                          age therefore most of them get psychologically disturbed.
                                          Therefore we as Love For The Poor come in to offer them
                                          services like counselling
                                        </p>
                                </div>
                              </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="cause-wrap">
                                <figure class="m-0">
                                    <img src="images/poverty.jpg" alt="">
                                    <div class="figure-overlay d-flex justify-content-center align-items-center position-absolute w-100 h-100">
                                        <a href="index.php#donate" class="btn gradient-bg mr-2">Donate Now</a>
                                    </div><!-- .figure-overlay -->
                                </figure>
                                <div class="cause-content-wrap">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <h3 class="entry-title w-100 m-0">
                                          <a href="poverty.php">Healthy/ Poverty</a></h3>
                                    </header><!-- .entry-header -->
                                    <div class="entry-content">
                                        <p class="m-0">
                                          War is not the only thing tearing Uganda apart.
                                          In a continent of famines, poverty and civil,
                                          Ugandans are struggling in their fight to survive.
                                          Ugandan’s health and life expectancy is one of the
                                          lowest worldwide.
                                        </p>
                                    </div><!-- .entry-content -->
                                </div><!-- .cause-content-wrap -->
                            </div><!-- .cause-wrap -->
                        </div><!-- .swiper-slide -->
                        <div class="swiper-slide">
                            <div class="cause-wrap">
                                <figure class="m-0">
                                    <img src="images/agriculture.jpg" alt="">
                                    <div class="figure-overlay d-flex justify-content-center align-items-center position-absolute w-100 h-100">
                                        <a href="index.php#donate" class="btn gradient-bg mr-2">Donate Now</a>
                                    </div><!-- .figure-overlay -->
                                </figure>
                                <div class="cause-content-wrap">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <h3 class="entry-title w-100 m-0">
                                          <a href="agric.php">Agriculture</a></h3>
                                    </header><!-- .entry-header -->
                                    <div class="entry-content">
                                        <p class="m-0">
                                          We have a plan to developed an Agriculture Project where
                                           we purchase fertile so we are in need of a land and
                                            proceed to plant and harvest crops. Local farmers
                                            are employed to work the land and train young men
                                        </p>
                                    </div>
                                </div><!-- .cause-content-wrap -->
                            </div><!-- .cause-wrap -->
                        </div><!-- .swiper-slide -->
                        <div class="swiper-slide">
                            <div class="cause-wrap">
                                <figure class="m-0">
                                    <img src="images/agricultu.jpg" alt="">
                                    <div class="figure-overlay d-flex justify-content-center align-items-center position-absolute w-100 h-100">
                                        <a href="index.php#donate" class="btn gradient-bg mr-2">Donate Now</a>
                                    </div><!-- .figure-overlay -->
                                </figure>
                                <div class="cause-content-wrap">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <h3 class="entry-title w-100 m-0">
                                          <a href="agric.php">Fight Covid 19</a></h3>
                                    </header><!-- .entry-header -->
                                    <div class="entry-content">
                                        <b>Our response to corona virus</b>
                                        <ul>
                                          <li>
                                            We reach out to the  community and educate
                                            them about the pendamic of corona virus.
                                          </li>
                                          <li>
                                            We feed the children from poor families that can buy food due to loss
                                            of jobs of their parent
                                          </li>
                                          <li>
                                            We encourage the community to follow on going Government guidelines.
                                          </li>
                                        </ul>
                                    </div>
                                </div><!-- .cause-content-wrap -->
                            </div><!-- .cause-wrap -->
                        </div><!-- .swiper-slide -->
                    </div><!-- .swiper-wrapper -->
                </div><!-- .swiper-container -->
                <!-- Add Arrows -->
                 
                <div class="swiper-button-next flex justify-content-center align-items-center">
                    <span><svg viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1171 960q0 13-10 23l-466 466q-10 10-23 10t-23-10l-50-50q-10-10-10-23t10-23l393-393-393-393q-10-10-10-23t10-23l50-50q10-10 23-10t23 10l466 466q10 10 10 23z"/></svg></span>
                </div>
                <div class="swiper-button-prev flex justify-content-center align-items-center">
                    <span><svg viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1203 544q0 13-10 23l-393 393 393 393q10 10 10 23t-10 23l-50 50q-10 10-23 10t-23-10l-466-466q-10-10-10-23t10-23l466-466q10-10 23-10t23 10l50 50q10 10 10 23z"/></svg></span>
                </div>
            </div><!-- .col -->
        </div><!-- .row -->
        	<div class="row">
                <div class="coL-12 col-lg-6">
                	<img src ="images/cause_5.jpg" width="100%" height="auto"/>
                </div>
                <div class="coL-12 col-lg-6">
                	<img src ="images/cause_6.jpg" width="100%" height="auto"/>
                </div>
             </div>
             <div class="row">
                 <div class="coL-12 col-lg-6">
                  <iframe width="100%;" height="300"
                        src="//www.youtube.com/embed/55Hl46aaNq0"
                        frameborder="0" allowfullscreen>
                    </iframe>
                </div>
                <div class="coL-12 col-lg-6">
                  <iframe width="100%;" height="300"
                        src="//www.youtube.com/embed/tlbf5o7ZY8Y"
                        frameborder="0" allowfullscreen>
                    </iframe>
                </div>
             </div>
    </div><!-- .container -->
</div><!-- .our-causes -->
