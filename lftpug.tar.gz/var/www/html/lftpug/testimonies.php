<div class="about-testimonial">
    <div class="container">
      <div class="row">
          <div class="coL-12">
              <div class="section-heading" style="padding-top:20px;">
                  <h2 class="entry-title">Testimonies</h2>
              </div><!-- .section-heading -->
          </div><!-- .col -->
      </div><!-- .row -->
        <div class="row">
            <div class="col-12 col-md-6 col-lg-5">
                <div class="testimonial-cont">
                    <div class="entry-content">
                        <p>
                          I am so glad to be associated with Love For The Poor.
                          Working with you has taught me how to give and love the most
                          vulnerable children.
                        </p>
                    </div>

                    <div class="entry-footer d-flex flex-wrap align-items-center mt-5">
                        <!-- <img src="images/testimonial-1.jpg" alt=""> -->

                        <h4>John Sserwadda, <span>Volunteer</span></h4>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 offset-lg-2 col-lg-5">
                <div class="testimonial-cont">
                    <div class="entry-content">
                        <p>
                          I have come to see to living gospel through this organisation.
                          You have brought hope into the hearts of these little vulnerable children.
                        </p>
                    </div>
                    <div class="entry-footer d-flex flex-wrap align-items-center mt-5">
                        <!-- <img src="images/testimonial-2.jpg" alt=""> -->
                        <h4>Ronald Ssemanda, <span>Doctor</span></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
