<?php include('templates/header.php'); ?>
                        <nav class="site-navigation d-flex justify-content-end align-items-center">
                            <ul class="d-flex flex-column flex-lg-row justify-content-lg-end align-content-center">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php">About us</a></li>
                                <li class="current-menu-item"><a href="causes.php">Causes</a></li>
                                <li><a href="portfolio.php">Gallery</a></li>
                                <li><a href="projects.php">Projects</a></li>
                                <li><a href="contact.php">Contact</a></li>
                            </ul>
                        </nav><!-- .site-navigation -->
                        <div class="hamburger-menu d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div><!-- .hamburger-menu -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .nav-bar -->
    </header><!-- .site-header -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 style="text-transform:uppercase;">Poor Feeding</h1>
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .page-header -->
    <div class="container">
        <div class="row elements-wrap">
            <div class="col-12">
                <div class="entry-content elements-container">
                    <div class="row">
                        <div class="col-12 col-md-12">
                          <p>
                            Approximately one million Ugandans have died painful deaths from illness,
                            many of which were easily preventable diseases. This has left an estimated
                            2.3 million children as orphans.
                          </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row elements-wrap">
            <div class="col-4">
                <div class="entry-content elements-container">
                    <div class="row">
                        <div class="col-12 col-md-12">
                          <img src="images/health1.jpg" alt="">
                          <p>
                              As seen above it is so painfull that many people in the rural areas
                               can't afford buying shoes for there children. Owing to the factor
                               that most of the roads here are full of dust, many chidren end
                               up having jiggers. So as an Organisation, we step in to buy for
                               them shoes to over the problems associated with children's not
                               putting on shoes.
                          </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="entry-content elements-container">
                    <div class="row">
                        <div class="col-12 col-md-12">
                          <img src="images/health2.jpg" alt="">
                          <p>
                              As shown before that there is limited food in
                              homes of the vulnerable, those who can access food in their homes
                              eat really very little food and of poor diet.
                          </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="entry-content elements-container">
                    <div class="row">
                        <div class="col-12 col-md-12">
                          <img src="images/health3.jpg" alt="">
                          <p>
                              Many people in rural areas are too poor that they can't dig pit Latrines.
                              The latrines they have are so much in poor situation that children
                              can easily fall in and they can also cause very many diseases e.g. typhiod.
                          </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div style="height: 96px"></div>
<?php include('templates/footer.php'); ?>
