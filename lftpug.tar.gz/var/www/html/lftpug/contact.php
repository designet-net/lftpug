<?php include('templates/header.php'); ?>
                    <nav class="site-navigation d-flex justify-content-end align-items-center">
                        <ul class="d-flex flex-column flex-lg-row justify-content-lg-end align-content-center">
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about.php">About us</a></li>
                            <li><a href="causes.php">Causes</a></li>
                            <li><a href="portfolio.php">Gallery</a></li>
                            <li><a href="projects.php">Projects</a></li>
                            <li class="current-menu-item"><a href="contact.php">Contact</a></li>
                        </ul>
                    </nav><!-- .site-navigation -->

                    <div class="hamburger-menu d-lg-none">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                    </div><!-- .hamburger-menu -->
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .nav-bar -->
</header><!-- .site-header -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 style="text-transform:uppercase;">Contact</h1>
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .page-header -->

    <div class="contact-page-wrap">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-5">
                    <div class="entry-content">
                        <h2>Get In touch with us</h2>
                        <p>
                          You can always feel free to send us an email, a message or give us a call.
                          We are always ready to respond.
                        </p>

                        <ul class="contact-social d-flex flex-wrap align-items-center">
                            <li><a href="https://www.facebook.com"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://www.twitter.com"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="https://www.instagram.com"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://www.linkedin.com"><i class="fa fa-linkedin"></i></a></li>
                        </ul>

                        <ul class="contact-info p-0">
                            <li><i class="fa fa-phone"></i>
                              <span>+256 753 492 567
                              <br> +256 775 779 112 </span>
                            </li>
                            <li><i class="fa fa-envelope"></i>
                              <span>info@lftug.org <br> loveforthepoor8@gmail.com</span>
                            </li>
                            <li><i class="fa fa-map-marker"></i><span>Mityana, Uganda - East Africa.</span></li>
                        </ul>
                    </div>
                </div><!-- .col -->
                <?php
                if(isset($_GET['submit'])){
                    $to = "info@lftpug.org";
                    $from = $_GET['email'];
                    $s_name = $_GET['s_name'];
                    $subject = "Form submission";
                    $subject2 = "Copy of your form submission";
                    $message =  $s_name . " wrote the following:" . "\n\n" . $_GET['message'];
                    $message2 = "Here is a copy of your message " . $s_name . "\n\n" . $_GET['message'];
                    $headers = "From:" . $from;
                    $headers2 = "From:" . $to;
                    mail($to,$subject,$message,$headers);
                    mail($from,$subject2,$message2,$headers2);
                    echo "Mail Sent. Thank you " . $s_name . ",we will contact you shortly.";
                    }
                ?>
                <div class="col-12 col-lg-7">
                    <form class="contact-form" method="get" action="contact.php">
                        <input type="text" placeholder="Name" name="s_name">
                        <input type="email" placeholder="Email" name="email">
                        <textarea rows="15" cols="6" placeholder="Messages" name="message"></textarea>
                        <span>
                            <input class="btn gradient-bg" type="submit" value="Contact us" name="submit">
                        </span>
                    </form><!-- .contact-form -->
                </div><!-- .col -->
                <div class="col-12" style="margin-top:40px;">
                    <!-- <div class="contact-gmap"> -->
                      <iframe width="100%" height="350px;" frameborder="0" style="border:0"
                        src="https://www.google.com/maps/embed/v1/place?q=Mityana,+Central+Region,
                        +Uganda&key=AIzaSyDwqxCthRVdequ-UQxQFbhfLBcLQbiw3SI">
                    </iframe>
                    <!-- </div> -->
                </div>
            </div><!-- .row -->
        </div><!-- .container -->
    </div>
<?php include('templates/footer.php'); ?>
