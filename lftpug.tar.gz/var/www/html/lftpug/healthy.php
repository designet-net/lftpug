<?php include('templates/header.php'); ?>
                        <nav class="site-navigation d-flex justify-content-end align-items-center">
                            <ul class="d-flex flex-column flex-lg-row justify-content-lg-end align-content-center">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php">About us</a></li>
                                <li><a href="causes.php">Causes</a></li>
                                <li><a href="portfolio.php">Gallery</a></li>
                                <li class="current-menu-item"><a href="projects.php">Projects</a></li>
                                <li><a href="contact.php">Contact</a></li>
                            </ul>
                        </nav><!-- .site-navigation -->
                        <div class="hamburger-menu d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div><!-- .hamburger-menu -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .nav-bar -->
    </header><!-- .site-header -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>Education</h1>
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .page-header -->
    <div class="container">
        <div class="row elements-wrap">
            <div class="col-12">
                <div class="entry-content elements-container">
                    <div class="row">
                        <div class="col-12 col-md-12">
                          <p>
                            Educate a child today, save them from a life of working in the streets,
                            and give them a future.
                            We are taught one of the most important things in life is to receive an education.
                            Unfortunately, many Ugandan children have never even heard of school.
                             Close to 18 percent of school-aged children are not enrolled in school
                             and the drop-out rate averages 66 percent.
                            Education is a key factor to national development,
                            yet in Uganda the opportunity to attend school comes with enormous challenges.
                             The most important and basic skill an African child can learn is to
                             be self-sufficient in relation to health, nutrition, environment and religion.
                             Uganda has very few free government schools despite the government’s ideology
                             to promote free primary education for all. These schools are hugely overpopulated,
                             often with one teacher to teach a class of 100 students.
                          </p>
                          <p>
                            The facilities are severely lacking with buildings often being half built,
                            no textbooks or learning aides. As a result, teachers are overworked and uninspired,
                            and simply cannot give children the one-on-one attention necessary.
                            Declining education standards has been attributed to the state in which these
                             free government are in. Therefore, to receive a good education,
                             the only real option is to attend a private school. But many cannot afford it.
                              The fees and quality vary quite significantly and most private schools have
                              extra costs for extras such as textbooks, shoe polish, brooms, blankets etc.
                              If a child does not have these extras, they cannot attend school. Fees must
                               be paid in full and in advance at the beginning of the school term.
                               No allowances are made and the children do not receive their reports
                               if fees are outstanding. The result is that children are at
                               home waiting to be able to attend school when they simply cannot.
                          </p>
                          <p>
                            As a result approximately 70 percent of adults are illiterate in Africa,
                            attributed to a lack of education and contributing to poverty and unemployment.
                            The key is to changing this is education.
                            Whilst it may seem in contradiction to the above facts, the government through
                            the Ministry of Education and Sports has the responsibility of providing
                             a high quality education at the lowest affordable cost and accessible by all.
                            Studies are being conducted and programs put in place to improve the severely
                             low standards of education provided. Sofar they have shown irregular performance,
                             over-subscription, inadequate facilities, deficiency of teachers and a
                             lack of support from authorities are contributing to the problem.
                          </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div style="height: 96px"></div>
<?php include('templates/footer.php'); ?>
