<?php include('templates/header.php'); ?>
                        <nav class="site-navigation d-flex justify-content-end align-items-center">
                            <ul class="d-flex flex-column flex-lg-row justify-content-lg-end align-content-center">
                                <li class="current-menu-item"><a href="index.php">Home</a></li>
                                <li><a href="about.php">About us</a></li>
                                <li><a href="causes.php">Causes</a></li>
                                <li><a href="portfolio.php">Gallery</a></li>
                                <li><a href="projects.php">Projects</a></li>
                                <li><a href="contact.php">Contact</a></li>
                            </ul> 
                        </nav><!-- .site-navigation -->
                        <div class="hamburger-menu d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div><!-- .hamburger-menu -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .nav-bar -->
    </header><!-- .site-header -->
    <div class="swiper-container hero-slider">
        <div class="swiper-wrapper">
            <div class="swiper-slide hero-content-wrap">
                <img src="images/home1.jpg" alt="" style="width:100%;height:650px;">
                <div class="hero-content-overlay position-absolute w-100 h-100">
                    <div class="container h-100">
                        <div class="row h-100">
                            <div class="col-12 col-lg-8 d-flex flex-column justify-content-center align-items-start">
                                <header class="entry-header">
                                    <h1>Our Vision</h1>
                                    <h4>Justice and free society for vulnerable children</h4>
                                </header><!-- .entry-header -->
                                <div class="entry-content mt-4">
                                    <p>They struggle to grow.</p>
                                </div><!-- .entry-content -->
                                <footer class="entry-footer d-flex flex-wrap align-items-center mt-5">
                                    <a href="index.php#donate" class="btn gradient-bg mr-2">Donate Now</a>
                                    <!-- <a href="#" class="btn orange-border">Read More</a> -->
                                </footer><!-- .entry-footer -->
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .container -->
                </div><!-- .hero-content-overlay -->
            </div><!-- .hero-content-wrap -->
            <div class="swiper-slide hero-content-wrap">
                <img src="images/home2.jpg" alt="" style="width:100%;height:650px;">
                <div class="hero-content-overlay position-absolute w-100 h-100">
                    <div class="container h-100">
                        <div class="row h-100">
                            <div class="col-12 col-lg-8 d-flex flex-column justify-content-center align-items-start">
                                <header class="entry-header">
                                    <h1>Take Action</h1>
                                    <h4>1 USD a day can help us provide a meal to the innocent children</h4>
                                </header><!-- .entry-header -->
                                <div class="entry-content mt-4">
                                    <p>Let us join hands.</p>
                                </div><!-- .entry-content -->
                                <footer class="entry-footer d-flex flex-wrap align-items-center mt-5">
                                    <a href="index.php#donate" class="btn gradient-bg mr-2">Donate Now</a>
                                    <!-- <a href="#" class="btn orange-border">Read More</a> -->
                                </footer><!-- .entry-footer -->
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .container -->
                </div><!-- .hero-content-overlay -->
            </div><!-- .hero-content-wrap -->
            <div class="swiper-slide hero-content-wrap">
                <img src="images/home3.jpg" alt="" style="width:100%;height:650px;">
                <div class="hero-content-overlay position-absolute w-100 h-100">
                    <div class="container h-100">
                        <div class="row h-100">
                            <div class="col-12 col-lg-8 d-flex flex-column justify-content-center align-items-start">
                                <header class="entry-header">
                                    <h1>Support Them</h1>
                                    <h4>They also need to grow like other children</h4>
                                </header><!-- .entry-header -->
                                <div class="entry-content mt-4">
                                    <p>Let us give them a chance.</p>
                                </div><!-- .entry-content -->
                                <footer class="entry-footer d-flex flex-wrap align-items-center mt-5">
                                    <a href="index.php#donate" class="btn gradient-bg mr-2">Donate Now</a>
                                    <!-- <a href="#" class="btn orange-border">Read More</a> -->
                                </footer><!-- .entry-footer -->
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .container -->
                </div><!-- .hero-content-overlay -->
            </div><!-- .hero-content-wrap -->
            <div class="swiper-slide hero-content-wrap">
                <img src="images/home4.jpg" alt="" style="width:100%;height:650px;">
                <div class="hero-content-overlay position-absolute w-100 h-100">
                    <div class="container h-100">
                        <div class="row h-100">
                            <div class="col-12 col-lg-8 d-flex flex-column justify-content-center align-items-start">
                                <header class="entry-header">
                                    <h1>Provision</h1>
                                    <h4>Thank you Lord for always supporting us in putting a meal on table</h4>
                                </header><!-- .entry-header -->
                                <div class="entry-content mt-4">
                                    <p>A good meal helps them grow.</p>
                                </div><!-- .entry-content -->
                                <footer class="entry-footer d-flex flex-wrap align-items-center mt-5">
                                    <a href="index.php#donate" class="btn gradient-bg mr-2">Donate Now</a>
                                    <!-- <a href="#" class="btn orange-border">Read More</a> -->
                                </footer><!-- .entry-footer -->
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .container -->
                </div><!-- .hero-content-overlay -->
            </div><!-- .hero-content-wrap -->
            <div class="swiper-slide hero-content-wrap">
                <img src="images/home5.jpg" alt="" style="width:100%;height:650px;">
                <div class="hero-content-overlay position-absolute w-100 h-100">
                    <div class="container h-100">
                        <div class="row h-100">
                            <div class="col-12 col-lg-8 d-flex flex-column justify-content-center align-items-start">
                                <header class="entry-header">
                                    <h1>Donate</h1>
                                    <h4>The needy children need our love</h4>
                                </header><!-- .entry-header -->
                                <div class="entry-content mt-4">
                                    <p>Why Not Take Action Today?</p>
                                </div><!-- .entry-content -->
                                <footer class="entry-footer d-flex flex-wrap align-items-center mt-5">
                                    <a href="index.php#donate" class="btn gradient-bg mr-2">Donate Now</a>
                                    <!-- <a href="#" class="btn orange-border">Read More</a> -->
                                </footer><!-- .entry-footer -->
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .container -->
                </div><!-- .hero-content-overlay -->
            </div><!-- .hero-content-wrap -->
            <div class="swiper-slide hero-content-wrap">
                <img src="images/home6.jpg" alt="" style="width:100%;height:650px;">
                <div class="hero-content-overlay position-absolute w-100 h-100">
                    <div class="container h-100">
                        <div class="row h-100">
                            <div class="col-12 col-lg-8 d-flex flex-column justify-content-center align-items-start">
                                <header class="entry-header">
                                    <h1>We Educate</h1>
                                </header><!-- .entry-header -->
                                <h4>They need education for a better future </h4>
                                <div class="entry-content mt-4">
                                    <p>Let Us Join Hands.</p>
                                </div><!-- .entry-content -->
                                <footer class="entry-footer d-flex flex-wrap align-items-center mt-5">
                                    <a href="index.php#donate" class="btn gradient-bg mr-2">Donate Now</a>
                                    <!-- <a href="#" class="btn orange-border">Read More</a> -->
                                </footer><!-- .entry-footer -->
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .container -->
                </div><!-- .hero-content-overlay -->
            </div><!-- .hero-content-wrap -->
            <div class="swiper-slide hero-content-wrap">
                <img src="images/home8.jpg" alt="" style="width:100%;height:650px;">
                <div class="hero-content-overlay position-absolute w-100 h-100">
                    <div class="container h-100">
                        <div class="row h-100">
                            <div class="col-12 col-lg-8 d-flex flex-column justify-content-center align-items-start">
                                <header class="entry-header">
                                    <h1>Join Us</h1>
                                    <h4>Let us always help them have a smile from within</h4>
                                </header><!-- .entry-header -->
                                <div class="entry-content mt-4">
                                    <p>It is a calling for us all.</p>
                                </div><!-- .entry-content -->
                                <footer class="entry-footer d-flex flex-wrap align-items-center mt-5">
                                    <a href="index.php#donate" class="btn gradient-bg mr-2">Donate Now</a>
                                    <!-- <a href="#" class="btn orange-border">Read More</a> -->
                                </footer><!-- .entry-footer -->
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .container -->
                </div><!-- .hero-content-overlay -->
            </div><!-- .hero-content-wrap -->
            <div class="swiper-slide hero-content-wrap">
                <img src="images/home9.jpg" alt="" style="width:100%;height:650px;">
                <div class="hero-content-overlay position-absolute w-100 h-100">
                    <div class="container h-100">
                        <div class="row h-100">
                            <div class="col-12 col-lg-8 d-flex flex-column justify-content-center align-items-start">
                                <header class="entry-header">
                                    <h1>Donate</h1>
                                    <h4>The shelters are in a very poor conditions. </h4>
                                </header><!-- .entry-header -->
                                <div class="entry-content mt-4">
                                    <p>Let's help them have where to sleep</p>
                                </div><!-- .entry-content -->
                                <footer class="entry-footer d-flex flex-wrap align-items-center mt-5">
                                    <a href="index.php#donate" class="btn gradient-bg mr-2">Donate Now</a>
                                    <!-- <a href="#" class="btn orange-border">Read More</a> -->
                                </footer><!-- .entry-footer -->
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .container -->
                </div><!-- .hero-content-overlay -->
            </div><!-- .hero-content-wrap -->
        </div><!-- .swiper-wrapper -->
        <div class="pagination-wrap position-absolute w-100">
            <div class="container">
                <div class="swiper-pagination"></div>
            </div><!-- .container -->
        </div><!-- .pagination-wrap -->
        <!-- Add Arrows -->
        <div class="swiper-button-next flex justify-content-center align-items-center">
            <span><svg viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1171 960q0 13-10 23l-466 466q-10 10-23 10t-23-10l-50-50q-10-10-10-23t10-23l393-393-393-393q-10-10-10-23t10-23l50-50q10-10 23-10t23 10l466 466q10 10 10 23z"/></svg></span>
        </div>
        <div class="swiper-button-prev flex justify-content-center align-items-center">
            <span><svg viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1203 544q0 13-10 23l-393 393 393 393q10 10 10 23t-10 23l-50 50q-10 10-23 10t-23-10l-466-466q-10-10-10-23t10-23l466-466q10-10 23-10t23 10l50 50q10 10 10 23z"/></svg></span>
        </div>
    </div><!-- .hero-slider -->
    <?php include('home_page_limestone.php');?>
    <div class="home-page-welcome">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-6 order-2 order-lg-1">
                    <div class="welcome-content">
                        <header class="entry-header">
                            <h2 class="entry-title heading">Who We Are</h2>
                        </header><!-- .entry-header -->
                        <div class="entry-content mt-5">
                            <p>
                                Love For The Poor Organisation Uganda (LFTP -UG) is a registered Non Profit
                                organization in Uganda. We were founded to help the most vulnerable children in the
                                different areas of Uganda. <br>
                                Driven by desire to have a justice free environment for children from poor families and
                                orphaned children, the Organisation was set up. <br>
                                We support children under our care with basics of life i.e.: Education, scholarstic material,
                                clothes, food,medication, etc.
                           </p>
                        </div><!-- .entry-content -->
                    </div><!-- .welcome-content -->
                </div><!-- .col -->
                <div class="col-12 col-lg-6 mt-4 order-1 order-lg-2">
                    <img src="images/welc.jpg" alt="welcome">
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .home-page-icon-boxes -->
    <?php include('home_page_events.php');?>
    <?php include('causes_section.php');?>
    <div class="container" style="margin-bottom:40px;padding-top:20px;" id="donate">
          <header class="entry-header">
              <h2 class="entry-title heading" style="text-transform:uppercase;text-align:center;">Take Action </h2>
          </header><!-- .entry-header -->
          <div class="row" style="margin-bottom:60px;">
            <div class="coL-12 col-lg-4">
              <!-- <button type="button" name="button" style="background-color:red;"> -->
                  <a href="https://www.paypal.me/douglftp?fbclid=IwAR2O4EEZEw8Dn4ul3_1qFNp6o9vVO_NvYdu4SzMgTIRnQc9AHYWCJ"
                    style="color:#fff;" class="btn gradient-bg mr-2">
                    Donate Now
                  </a>
              <!-- </button> -->
            </div>
          </div>
        <div class="row">
            <div class="coL-12 col-lg-4">
                <h6 class="entry-title heading" style="text-transform:uppercase;">By Bank Account</h6>
                <p> <b>Bank Name:</b> Equity Bank </p>
                <p> <b>Account Name:</b> Love For The Poor Ltd.</p>
                <p><b>Account Number:</b> 1016200955011 </p>
                <p> <b>Swift code:</b>  EQBLUGKA</p>
                <p> <b>Email: </b>info@lftpug.org  </p>
            </div>
            <div class="coL-12 col-lg-4">
                <h6 class="entry-title heading" style="text-transform:uppercase;">By Western Union/ Money Gram</h6>
                <p> <b>Reciever's Country:</b> Uganda</p>
                <p> <b>Reciever's Name: </b> Katongole Kenston</p>
                <p> <b>Country code:</b> +256</p>
            </div>
            <div class="coL-12 col-lg-4">
                <h6 class="entry-title heading" style="text-transform:uppercase;">By Worldremit</h6>
                <p> <b>Link</b> <a href="https://www.worldremit.com/en/uganda">
                  https://www.worldremit.com/en/uganda</a></p>
                <p> <b>Reciever's Country:</b> Uganda</p>
                <p> <b>Moblie Money: </b> MTN(+256775779112)</p>
                <p> <b>Email:</b> info@lftpug.org</p>
            </div>
        </div>
    </div>
    <?php include('sponsor.php'); ?>
    <?php include('templates/footer.php'); ?>