<div class="home-page-limestone">
    <div class="container" style="margin-bottom:40px;">
    	<div class="row align-items-end">
        	<div class="coL-12 col-lg-12">
            	<div class="section-heading">
                  <h2 class="entry-title">
                   Welcome
                  </h2>
                  <h6 style="margin:20px;">
                  	<b style="color:red;text-transform:uppercase;">It is most blessed to give than to recieve</b> <br/>
                  	Love For The Poor was started by Katongole Kenston through the mercy and the love of God to help the most 
                    vulnerable children (the orphans, street children and the disabled) from the 
                    different areas of Uganda.<br/> Amidst a number of challenges as reflected from Low Developed Countries, 
                    we have managed to help these little poor angels have hope to the future.
                  </h6>
                 </div> 
            </diV>
             <div class="coL-12 col-lg-6">
             	<img src ="images/home_gal1.jpg" width="100%" height="auto"/>
            </div>
            <div class="coL-12 col-lg-6">
             	<img src ="images/home_gal2.jpg" width="100%" height="auto"/>
            </div>
            <div class="coL-12 col-lg-6">
             	<img src ="images/home_gal3.jpg" width="100%" height="auto"/>
            </div>
            <div class="coL-12 col-lg-6">
             	<img src ="images/home_gal4.jpg" width="100%" height="auto"/>
            </div>
            <div class="coL-12 col-lg-12">
            	<div class="section-heading">
                  <p style="margin:20px;font-size:22px;">
                  	<b style="color:red;">Whoever is kind to the poor lends to the Lord. (Proverbs 19:17)</b> <br/>
                    Dear brethren we accept gifts in form of money and non monetory form. Let us help the little vulnerable, let us lend to 
                    the Lord. Amen.
                  </p>
                 </div> 
            </diV>
        </div>
        <div class="row align-items-end">
            <div class="coL-12 col-lg-6">
              <iframe width="100%;" height="300"
                    src="//www.youtube.com/embed/vhn8w5Y1xv8"
                    frameborder="0" allowfullscreen>
                </iframe>
            </div>
            <div class="coL-12 col-lg-6">
              <iframe width="100%;" height="300"
                    src="//www.youtube.com/embed/7qJ6ZjM79eo"
                    frameborder="0" allowfullscreen>
                </iframe>
            </div>
            <div class="coL-12 col-lg-6">
             	<img src ="images/home_g1.jpg" width="100%" height="auto"/>
            </div>
            <div class="coL-12 col-lg-6">
             	<img src ="images/home_g2.jpg" width="100%" height="auto"/>
            </div>
            <div class="coL-12 col-lg-6">
             	<img src ="images/home_g3.jpg" width="100%" height="auto"/>
            </div>
            <div class="coL-12 col-lg-6">
             	<img src ="images/home_g4.jpg" width="100%" height="auto"/>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row align-items-end">
            <div class="coL-12 col-lg-6">
                <div class="section-heading">
                    <h2 class="entry-title">
                      We love to help all the most vulnerable children in the world. <br>
                      This our goal.
                    </h2>
                    <p class="mt-5">
                      In our struggle to achieve our goal,
                      we have helped a number of disadvantaged children and we
                      have given them light to the future.
                    </p>
                </div><!-- .section-heading -->
            </div><!-- .col -->
            <div class="col-12 col-lg-6">
                <div class="milestones d-flex flex-wrap justify-content-between">
                    <div class="col-12 col-sm-4 mt-5 mt-lg-0">
                        <div class="counter-box">
                            <div class="d-flex justify-content-center align-items-center">
                                <img src="images/teamwork.png" alt="">
                            </div>
                            <div class="d-flex justify-content-center align-items-baseline">
                                <div class="start-counter" data-to="156" data-speed="2000"></div>
                            </div>
                            <h3 class="entry-title">Children helped</h3><!-- entry-title -->
                        </div><!-- counter-box -->
                    </div><!-- .col -->
                    <div class="col-12 col-sm-4 mt-5 mt-lg-0">
                        <div class="counter-box">
                            <div class="d-flex justify-content-center align-items-center">
                                <img src="images/donation.png" alt="">
                            </div>
                            <div class="d-flex justify-content-center align-items-baseline">
                                <div class="start-counter" data-to="5" data-speed="2000"></div>
                            </div>
                            <h3 class="entry-title">Water wells</h3><!-- entry-title -->
                        </div><!-- counter-box -->
                    </div><!-- .col -->
                    <div class="col-12 col-sm-4 mt-5 mt-lg-0">
                        <div class="counter-box">
                            <div class="d-flex justify-content-center align-items-center">
                                <img src="images/dove.png" alt="">
                            </div>
                            <div class="d-flex justify-content-center align-items-baseline">
                                <div class="start-counter" data-to="3" data-speed="2000"></div>
                            </div>
                            <h3 class="entry-title">Volunteers</h3><!-- entry-title -->
                        </div><!-- counter-box -->
                    </div><!-- .col -->
                </div><!-- .milestones -->
            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container -->
</div><!-- .our-causes -->
