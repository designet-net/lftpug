<div class="home-page-events">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-6">
                <div class="upcoming-events">
                    <div class="section-heading">
                        <h2 class="entry-title">Events In History</h2>
                    </div><!-- .section-heading -->
                    <div class="event-wrap d-flex flex-wrap justify-content-between">
                        <figure class="m-0">
                            <img src="images/books.jpg" alt="">
                        </figure>
                        <div class="event-content-wrap">
                            <header class="entry-header d-flex flex-wrap align-items-center">
                                <h3 class="entry-title w-100 m-0"><a href="donate.php">Donating  books</a></h3>
                                <div class="posted-date">
                                    <a href="causes.php">January 26, 2021 </a>
                                </div><!-- .posted-date -->
                                <div class="cats-links">
                                    <a href="causes.php">Kiyoganyi, Mityana.</a>
                                </div><!-- .cats-links -->
                            </header><!-- .entry-header -->
                            <div class="entry-content">
                                <p class="m-0">
                                  We will be donating books to these vulnerable children
                                  as a way of supporting them in school this term
                                </p>
                            </div><!-- .entry-content -->
                        </div><!-- .event-content-wrap -->
                    </div><!-- .event-wrap -->
                    <div class="event-wrap d-flex flex-wrap justify-content-between">
                        <figure class="m-0">
                            <img src="images/feeding_1.jpg" alt="">
                        </figure>
                        <div class="event-content-wrap">
                            <header class="entry-header d-flex flex-wrap align-items-center">
                                <h3 class="entry-title w-100 m-0"><a href="#">Feeding the needy Campaign</a></h3>

                                <div class="posted-date">
                                    <a href="causes.php">February 22, 2021 </a>
                                </div><!-- .posted-date -->

                                <div class="cats-links">
                                    <a href="causes.php">Kikumbi Mityana</a>
                                </div><!-- .cats-links -->
                            </header><!-- .entry-header -->
                            <div class="entry-content">
                                <p class="m-0">
                                  In our Campaign to help those who go with empty stomachs,
                                  we will meet the community of Kikumbi as way of calling
                                  upon them to join us in helping the needy who have nothing to eat.
                                </p>
                            </div><!-- .entry-content -->
                        </div><!-- .event-content-wrap -->
                    </div><!-- .event-wrap -->
                    <div class="event-wrap d-flex flex-wrap justify-content-between">
                        <figure class="m-0">
                            <img src="images/sanitary.jpg" alt="">
                        </figure>
                        <div class="event-content-wrap">
                            <header class="entry-header d-flex flex-wrap align-items-center">
                                <h3 class="entry-title w-100 m-0"><a href="cause.php">Donating Sanitary pads</a></h3>

                                <div class="posted-date">
                                    <a href="causes.php">May 25, 2021 </a>
                                </div><!-- .posted-date -->

                                <div class="cats-links">
                                    <a href="causes.php">Mityana Town Council</a>
                                </div><!-- .cats-links -->
                            </header><!-- .entry-header -->

                            <div class="entry-content">
                                <p class="m-0">
                                  We shall be donating sanitary pads to all the girls
                                  vulnerable children in Mityana Town Council.
                                </p>
                            </div><!-- .entry-content -->
                        </div><!-- .event-content-wrap -->
                    </div><!-- .event-wrap -->
                </div><!-- .upcoming-events -->
            </div><!-- .col -->
            <div class="col-12 col-lg-6">
                <div class="featured-cause">
                    <div class="section-heading">
                        <h2 class="entry-title">Featured Cause</h2>
                    </div><!-- .section-heading -->
                    <iframe src="  https://www.gofundme.com/funds-for-love-for-the-poor-uganda?fbclid=IwAR1PXI4HUPnePaoQwXv_PkPVNrAkwgf2elqC3ATFcBrq5am-kR8BHImYYak"
                      width="100%" height="500px" border="0">
                  </iframe>
                </div><!-- .featured-cause -->
            </div><!-- .col -->
        </div><!-- .row -->
    </div><!-- .container -->
</div><!-- .home-page-events -->
