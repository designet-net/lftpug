<?php include('templates/header.php'); ?>
                        <nav class="site-navigation d-flex justify-content-end align-items-center">
                            <ul class="d-flex flex-column flex-lg-row justify-content-lg-end align-content-center">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php">About us</a></li>
                                <li class="current-menu-item"><a href="causes.php">Causes</a></li>
                                <li><a href="portfolio.php">Gallery</a></li>
                                <li><a href="projects.php">Projects</a></li>
                                <li><a href="contact.php">Contact</a></li>
                            </ul>
                        </nav><!-- .site-navigation -->
                        <div class="hamburger-menu d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div><!-- .hamburger-menu -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .nav-bar -->
    </header><!-- .site-header -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 style="text-transform:uppercase;">Poor Feeding</h1>
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .page-header -->
    <div class="container">
        <div class="row elements-wrap">
            <div class="col-12">
                <div class="entry-content elements-container">
                    <div class="row">
                        <div class="col-12 col-md-12">
                          <p>
                            Many people in the world are dying because of poor feeding.
                            It is our vision as Love For The Poor Organisation to put an
                            end to this. We call upon people around the world to join us in this call.
                          </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row elements-wrap">
            <div class="col-4">
                <div class="entry-content elements-container">
                    <div class="row">
                        <div class="col-12 col-md-12">
                          <img src="images/feeding1.jpg" alt="">
                          <p>
                              Because of limited food in our communities the vulnerable
                              children end up feeding on jack fruits. These works as their
                              meals(break fast, lunch and supper). This does not only affect
                              the vulnerable children but the mature people also who take care of them.
                          </p>
                          <p>
                            Diseases caused by poor feeding include: diabetes, anemia, rickets.
                          </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="entry-content elements-container">
                    <div class="row">
                        <div class="col-12 col-md-12">
                          <img src="images/feeding2.jpg" alt="">
                          <p>
                              As shown before that there is limited food in
                              homes of the vulnerable, those who can access food in their homes
                              eat really very little food and of poor diet.
                          </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="entry-content elements-container">
                    <div class="row">
                        <div class="col-12 col-md-12">
                          <img src="images/feeding3.jpg" alt="">
                          <p>
                              Because of unstable whelther seasons.
                              The poor people grow crops which end up dying in the gardens.
                               More than 60% of the Ugandans can't aford the irrigation.
                               And it is this food which the Ugandans would sell and take
                               care of their children, and the rest would be for them to eat.
                          </p>
                          <p>
                            Many of the Ugandans who have HIV/AIDS have stopped taking
                            the drugs since they can take some days with out eating a meal.
                          </p>
                          <p>
                            Therefore we The Love For The Poor organisation come in to solve the problem of
                            poor feeding by providing food to the vulnerable in their communities.
                          </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div style="height: 96px"></div>
<?php include('templates/footer.php'); ?>
