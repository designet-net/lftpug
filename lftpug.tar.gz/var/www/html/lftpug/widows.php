<?php include('templates/header.php'); ?>
                        <nav class="site-navigation d-flex justify-content-end align-items-center">
                            <ul class="d-flex flex-column flex-lg-row justify-content-lg-end align-content-center">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php">About us</a></li>
                                <li class="current-menu-item"><a href="causes.php">Causes</a></li>
                                <li><a href="portfolio.php">Gallery</a></li>
                                <li><a href="projects.php">Projects</a></li>
                                <li><a href="contact.php">Contact</a></li>
                            </ul>
                        </nav><!-- .site-navigation -->
                        <div class="hamburger-menu d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div><!-- .hamburger-menu -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .nav-bar -->
    </header><!-- .site-header -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 style="text-transform:uppercase;">Widows</h1>
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .page-header -->
    <div class="container">
        <div class="row elements-wrap">
            <div class="col-12">
                <div class="entry-content elements-container">
                    <div class="row">
                        <div class="col-12 col-md-12">
                          <p>
                            Many of the widows in Uganda lose their husbands at an early age
                            therefore most of them get psychologically disturbed. Therefore we as
                             Love For The Poor come in to offer them services like counselling and
                             guidance through life.
                          </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div style="height: 96px"></div>
<?php include('templates/footer.php'); ?>
