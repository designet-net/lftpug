<?php include('templates/header.php'); ?>
                        <nav class="site-navigation d-flex justify-content-end align-items-center">
                            <ul class="d-flex flex-column flex-lg-row justify-content-lg-end align-content-center">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php">About us</a></li>
                                <li><a href="causes.php">Causes</a></li>
                                <li class="current-menu-item"><a href="portfolio.php">Gallery</a></li>
                                <li><a href="projects.php">Projects</a></li>
                                <li><a href="contact.php">Contact</a></li>
                            </ul>
                        </nav><!-- .site-navigation -->
                        <div class="hamburger-menu d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div><!-- .hamburger-menu -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .nav-bar -->
    </header><!-- .site-header -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 style="text-transform:uppercase;">Gallery</h1>
                </div><!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .page-header -->
    <div class="portfolio-wrap">
        <div class="container">
            <div class="row portfolio-container">
                <div class="col-12 col-md-6 col-lg-4 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/1.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">
                          Vulnerable children need your helping hand.
                          </a>
                        </h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-3 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/2.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">We need access to clean water</a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-5 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/3.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">
                          You can be the key to a smile of the little
                        vulnerable children in our community.
                      </a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-5 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/4.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">
                          Your contribution can help the little Children
                          have better bedding.
                        </a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-3 mt-48 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/5.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">
                          &ldquo; Thank you our friends and donars for making us smile.&rdquo;
                        </a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mt-48 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/6.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">
                          Many children in schools can not afford full school uniforms.</a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-3 mt-72 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/7.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">
                          Help me have the light to the future.
                         </a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6 mt-72 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/8.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">
                          &ldquo;You can find the smile of Christ in the eyes of these little ones.&rdquo;
                        </a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-3 mt-72 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/9.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">
                          We can all work together to feed the vulnerable
                        </a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/1.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">Vulnerable children need your helping hand.</a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-3 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/2.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">We need access to clean water</a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-5 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/3.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">
                          You can be the key to a smile of the little
                      vulnerable children in our community.</a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-5 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/4.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">
                          Your contribution can help the little Children
                        have better bedding.</a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-3 mt-48 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/5.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">
                          &ldquo; Thank you our friends and donars for making us smile.&rdquo;
                        </a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mt-48 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/6.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">
                          Many children in schools can not afford full school uniforms.</a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-3 mt-72 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/7.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">Help me have the light to the future.</a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6 mt-72 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/8.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">
                          &ldquo;You can find the smile of Christ in the eyes of these little ones.&rdquo;
                        </a></h3>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-3 mt-72 portfolio-item">
                    <div class="portfolio-cont">
                        <a href="#"><img src="images/9.jpg" alt=""></a>
                        <h3 class="entry-title"><a href="#">We can all work together to feed the vulnerable</a></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include('templates/footer.php'); ?>
